﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Shopbridge_base.Data;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;

namespace Shopbridge_base.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService productService;
        private readonly ILogger<ProductsController> logger;
        DbContextOptions<Shopbridge_Context> options = new DbContextOptions<Shopbridge_Context>();
        
        public ProductsController(IProductService _productService)
        {
            this.productService = _productService;
        }

       
        [HttpGet]   
        public async Task<ActionResult<IEnumerable<Product>>> GetProduct()
        {
            List<Product> product ;
            using (var context = new Shopbridge_Context(options))
            {
                product = (from d in context.Product  select d).ToList<Product>();
            }
            return product;
        }

        
        [HttpGet("{id}")]
        public async Task<ActionResult<Product>> GetProduct(int id)
        {
            Product product;
            using (var context = new Shopbridge_Context(options))
            {
                 product = (from d in context.Product
                               where d.Product_Id == id
                               select d).ToList<Product>().FirstOrDefault();
            }
            return product;
        }

       
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, Product product)
        {
            using (var context = new Shopbridge_Context(options))
            {
                var updatedProduct = (from d in context.Product
                               where d.Product_Id == id
                               select d).Single();
                updatedProduct.Product_Name = product.Product_Name;
                updatedProduct.Description = product.Description;
                updatedProduct.Price = product.Price;
                context.SaveChanges();
            }
            return NoContent();
        }

        
        [HttpPost]
        public async Task<ActionResult<Product>> PostProduct(Product product)
        {
            using (var context = new Shopbridge_Context(options))
            {

                //Product productData = new Product
                //{
                //    Product_Id = 001,
                //    Product_Name = "Parle",
                //    Description = "Biscuit",
                //    Price = 65
                //};

                context.Product.Add(product);
                context.SaveChanges();
            }

            return NoContent();
        }

        
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            using (var context = new Shopbridge_Context(options))
            {
                var p1 = (from d in context.Product where d.Product_Id == id select d).Single();
                context.Product.Remove(p1);
                context.SaveChanges();
            }
            return NoContent();
        }

        private bool ProductExists(int id)
        {
            return false;
        }
    }
}
